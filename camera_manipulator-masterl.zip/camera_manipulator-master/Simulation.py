import rospy
import numpy as np
import tf
from geometry_msgs.msg import Transform, Vector3, Quaternion, Point, Pose
from scipy.spatial.transform import Rotation
from Kinematics import Kinematics
import roslaunch
np.set_printoptions(precision=5, suppress=True)


class Simulation:
    def __init__(self):
        if not rospy.get_node_uri():
            rospy.init_node("camera_manipulator", anonymous=True)
        else:
            rospy.logdebug(rospy.get_caller_id() + ' -> ROS already initialized')

        # config
        self.n_seg = 3      # the first two segment are coupled
        self.n_disk = [2, 2, 5]     # number of disk per each segment
        self.r_ee_marker = 6

        # dimension
        self.L_shaft = 50
        self.r_shaft = 8
        self.L_disk = [3, 3, 3]
        self.r_disk = [6, 6, 5]

        # transform broadcaster
        self.br = tf.TransformBroadcaster()

        # create URDF
        self.createURDF()
        rospy.sleep(0.5)

        uuid = roslaunch.rlutil.get_or_generate_uuid(None, False)
        roslaunch.configure_logging(uuid)
        launch = roslaunch.parent.ROSLaunchParent(uuid, ["./description/sim.launch"])
        launch.start()

    def update_segment(self, bend, length, idx_seg):
        L = length
        self.br.sendTransform(translation=[0.0, 0.0, 0.0], rotation=Rotation.from_euler('z', bend[0]).as_quat(),
                              time=rospy.Time.now(), child="S" + str(idx_seg) + "L0", parent="S" + str(idx_seg) + "Lbase")
        path = np.linspace(start=0.0, stop=L, num=self.n_disk[idx_seg])
        for i, s in enumerate(path[1:], start=1):
            if bend[1] == 0:
                pos_link = np.array([0.0, 0.0, s])
            else:
                pos_link = np.array([L/bend[1]*(1-np.cos(bend[1]/L*s)), 0., L/bend[1]*np.sin(bend[1]/L*s)])
            if i == len(path)-1:    # for the last link
                R1 = Rotation.from_euler('y', s*bend[1]/L).as_matrix()
                R2 = Rotation.from_euler('z', -bend[0]).as_matrix()
                quat_link = Rotation.from_matrix(R1@R2).as_quat()
            else:
                quat_link = Rotation.from_euler('y', s*bend[1]/L).as_quat()
            self.br.sendTransform(translation=pos_link, rotation=quat_link, time=rospy.Time.now(),
                                  child="S"+str(idx_seg)+"L"+str(i),
                                  parent="S"+str(idx_seg)+"L0")

    def update(self, joints, vars):
        q1, q2, q3, q4, q5, q6 = joints
        L1, L2 = vars

        # update base link
        self.br.sendTransform(translation=[0.0, 0.0, 0.0], rotation=[0.0, 0.0, 0.0, 1.0],
                              time=rospy.Time.now(), child="base_link", parent="RCM")

        # update outer shaft
        self.br.sendTransform(translation=[0.0, 0.0, q1-self.L_shaft/2], rotation=[0.0, 0.0, 0.0, 1.0],
                              time=rospy.Time.now(), child="link_shaft", parent="base_link")

        # update base of the 1st segment
        self.br.sendTransform(translation=[0.0, 0.0, self.L_shaft/2], rotation=Rotation.from_euler('z', q2).as_quat(),
                              time=rospy.Time.now(), child="S0Lbase", parent="link_shaft")
        self.br.sendTransform(translation=[0.0, 0.0, 0.0], rotation=[0.0, 0.0, 0.0, 1.0],
                              time=rospy.Time.now(), child="S1Lbase", parent="S0L"+str(self.n_disk[0]-1))

        # update base of the 2nd segment
        self.br.sendTransform(translation=[0.0, 0.0, 0.0], rotation=[0.0, 0.0, 0.0, 1.0],
                              time=rospy.Time.now(), child="S2Lbase", parent="S1L"+str(self.n_disk[1]-1))

        # update segments
        self.update_segment(bend=[q3, q4], length=L1/2, idx_seg=0)     # 1st segment
        self.update_segment(bend=[q3, -q4], length=L1/2, idx_seg=1)     # 2nd segment
        self.update_segment(bend=[q5, q6], length=L2, idx_seg=2)     # 3rd segment

    def update_kin(self, joints, vars):
        Tbe = Kinematics.fk(joints=joints, vars=vars)[0][-1]
        self.br.sendTransform(translation=Tbe[:3, -1], rotation=Rotation.from_matrix(Tbe[:3, :3]).as_quat(),
                              time=rospy.Time.now(), child="link_ee_marker", parent="base_link")

    @classmethod
    def numpy_to_pose(cls, pos, quat, arr):
        shape, rest = arr.shape[:-2], arr.shape[-2:]
        assert rest == (4, 4)
        return Pose(position=Point(**dict(zip(['x', 'y', 'z'], pos))),
                    orientation=Quaternion(**dict(zip(['x', 'y', 'z', 'w'], quat))))

    @classmethod
    def transform_to_pq(cls, T):
        pos = T[:3, -1]
        quat = Rotation.from_matrix(T[:3, :3]).as_quat()
        return pos, quat

    def createURDF(self):
        with open("./description/continuum.urdf", 'w') as file:
            file.write("<?xml version=\"1.0\"?>\n")
            file.write("<robot name=\"continuum_robot\">\n")
            file.write("<link name=\"RCM\"/>\n")

            file.write("<material name=\"color\">\n")
            file.write("<color rgba=\"0 1 1 1\"/>\n")
            file.write("</material>\n\n")
            file.write("<material name=\"yellow\">\n")
            file.write("<color rgba=\"1 1 0 1\"/>\n")
            file.write("</material>\n\n")

            file.write("<link name=\"base_link\">\n")
            file.write("<visual>\n")
            file.write("<geometry>\n")
            file.write("<cylinder length=\"3.0\" radius=\"10.0\"/>\n")
            file.write("</geometry>\n")
            file.write("<material name=\"yellow\"/>\n")
            file.write("</visual>\n")
            file.write("</link>\n\n")

            file.write("<joint name=\"base_joint\" type=\"floating\">\n")
            file.write("<parent link=\"RCM\"/>\n")
            file.write("<child link=\"base_link\"/>\n")
            file.write("</joint>\n\n")

            file.write("<link name=\"link_shaft\">\n")
            file.write("<visual>\n")
            file.write("<geometry>\n")
            file.write("<cylinder length=\"" + str(self.L_shaft) + "\" radius=\"" + str(self.r_shaft) + "\"/>\n")
            file.write("<origin rpy=\"0 0 0\" xyz=\"0 0 0\"/>\n")
            file.write("</geometry>\n")
            file.write("<material name=\"color\"/>\n")
            file.write("</visual>\n")
            file.write("</link>\n\n")

            file.write("<joint name=\"joint_shaft\" type=\"floating\">\n")
            file.write("<parent link=\"base_link\"/>\n")
            file.write("<child link=\"link_shaft\"/>\n")
            file.write("</joint>\n\n")
            for s in range(self.n_seg):
                file.write("<link name=\"S" + str(s) + "Lbase\"/>\n")
                file.write("<joint name=\"S" + str(s) + "Jbase\" type=\"floating\">\n")
                file.write("<parent link=\"base_link\"/>\n")
                file.write("<child link=\"S" + str(s) + "Lbase\"/>\n")
                file.write("</joint>\n\n")
                for d in range(self.n_disk[s]):
                    file.write("<link name=\"S" + str(s) + "L" + str(d) + "\">\n")
                    file.write("<visual>\n")
                    file.write("<geometry>\n")
                    file.write("<cylinder length=\"" + str(self.L_disk[s]) + "\" radius=\"" + str(self.r_disk[s]) + "\"/>\n")
                    file.write("<origin rpy=\"0 0 0\" xyz=\"0 0 0\"/>\n")
                    file.write("</geometry>\n")
                    file.write("<material name=\"color\"/>\n")
                    file.write("</visual>\n")
                    file.write("</link>\n\n")

                    file.write("<joint name=\"S" + str(s) + "J" + str(d) + "\" type=\"floating\">\n")
                    file.write("<parent link=\"base_link\"/>\n")
                    file.write("<child link=\"S" + str(s) + "L" + str(d) + "\"/>\n")
                    file.write("</joint>\n\n")

            # ee marker
            file.write("<link name=\"link_ee_marker\">\n")
            file.write("<visual>\n")
            file.write("<geometry>\n")
            file.write("<sphere radius=\"" + str(self.r_ee_marker) + "\"/>\n")
            file.write("</geometry>\n")
            file.write("<material name=\"marker_color\">\n")
            file.write("<color rgba=\"1 0 0 1\"/>\n")
            file.write("</material>\n")
            file.write("</visual>\n")
            file.write("</link>\n\n")

            file.write("<joint name=\"joint_ee_marker\" type=\"floating\">\n")
            file.write("<parent link=\"base_link\"/>\n")
            file.write("<child link=\"link_ee_marker\"/>\n")
            file.write("</joint>\n\n")
            file.write("</robot>\n\n")


if __name__ == "__main__":
    sim = Simulation()
    t = 0.0
    # try:
    #     launch.spin()
    # finally:
    #     launch.shutdown()
    while not rospy.is_shutdown():
        joints = [np.pi/3*np.sin(2*np.pi*t/3)]*6
        # joints[0] = 0.0     # trans
        # joints[1] = 0.0     # roll
        # joints[2] = 0.0     # bending (1st seg)
        # joints[3] = 0.0     # bending (1st seg)
        # joints[4] = 0.0     # bending (2nd seg)
        # joints[5] = 0.0     # bending (2nd seg)
        sim.update(joints=joints, vars=[60, 40])
        sim.update_kin(joints=joints, vars=[60, 40])
        rospy.sleep(0.001)
        t += 0.001
