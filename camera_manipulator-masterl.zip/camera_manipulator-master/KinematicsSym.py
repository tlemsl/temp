import sympy as sym
from sympy import sin, cos, simplify, pprint


def DH_transform(alpha, a, d, theta):
    T = sym.Matrix([[cos(theta), -sin(theta), 0, a],
                    [sin(theta) * cos(alpha), cos(theta) * cos(alpha), -sin(alpha), -sin(alpha) * d],
                    [sin(theta) * sin(alpha), cos(theta) * sin(alpha), cos(alpha), cos(alpha) * d],
                    [0, 0, 0, 1]])
    return T

L1, L2 = sym.symbols('L1, L2')
q1, q2, q3, q4, q5, q6 = sym.symbols('q1, q2, q3, q4, q5, q6')
T01 = DH_transform(0,         0,    q1,         0)
T12 = DH_transform(0,         0,     0,        q2)
T23 = DH_transform(0,         0,     0,        q3)
T34 = DH_transform(sym.pi/2,  0,     0,        -q4/2)
T45 = DH_transform(-sym.pi/2, 0,     2*L1/q4*sym.sin(q4/2),        0)
T56 = DH_transform(sym.pi/2,  0,     0,        q4/2)
T67 = DH_transform(-sym.pi/2, 0,     0,        -q3)
T78 = DH_transform(0,         0,     0,         q5)
T89 = DH_transform(sym.pi/2,  0,     0,         -q6/2)
T910 = DH_transform(-sym.pi/2, 0,     2*L2/q6*sym.sin(q6/2),       0)
T1011 = DH_transform(sym.pi/2,  0,     0,       -q6/2)
T11e = DH_transform(-sym.pi/2, 0,     0,       -q5)

T02 = T01*T12
T03 = T02*T23
T04 = T03*T34
T05 = T04*T45
T06 = T05*T56
T07 = T06*T67
T08 = T07*T78
T09 = T08*T89
T010 = T09*T910
T011 = T010*T1011
T0e = T011*T11e

# Position
px = T0e[0, 3]
py = T0e[1, 3]
pz = T0e[2, 3]

J = sym.zeros(6, 6)
J[0, 0] = sym.diff(px, q1)
J[0, 1] = sym.diff(px, q2)
J[0, 2] = sym.diff(px, q3)
J[0, 3] = sym.diff(px, q4)
J[0, 4] = sym.diff(px, q5)
J[0, 5] = sym.diff(px, q6)

J[1, 0] = sym.diff(py, q1)
J[1, 1] = sym.diff(py, q2)
J[1, 2] = sym.diff(py, q3)
J[1, 3] = sym.diff(py, q4)
J[1, 4] = sym.diff(py, q5)
J[1, 5] = sym.diff(py, q6)

J[2, 0] = sym.diff(pz, q1)
J[2, 1] = sym.diff(pz, q2)
J[2, 2] = sym.diff(pz, q3)
J[2, 3] = sym.diff(pz, q4)
J[2, 4] = sym.diff(pz, q5)
J[2, 5] = sym.diff(pz, q6)

# J[3:, 0] = T01[:3, 2]
# J[3:, 1] = T02[:3, 2]
# J[3:, 2] = T03[:3, 2]
# J[3:, 3] = T04[:3, 2]
# J[3:, 4] = T05[:3, 2]
# J[3:, 5] = T06[:3, 2]
# J[3:, 6] = T07[:3, 2]

joints = [4.0, -0.702, -0.678, -0.238, -0.365, 0.703]

print (J.subs(([(q1, joints[0]), (q2, joints[1]), (q3, joints[2]), (q4, joints[3]), (q5, joints[4]), (q6, joints[5]), (L1, 10), (L2, 10)])))
import pdb; pdb.set_trace()

# for i in range(6):
#     for j in range(7):
#         print ("J[",i,", ",j,"] = ", J[i, j])