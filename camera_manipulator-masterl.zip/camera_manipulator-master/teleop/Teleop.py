#!/usr/bin/env python3
import rospy
import numpy as np
from sensor_msgs.msg import JointState
from camera_manipulator.Kinematics import Kinematics
from camera_manipulator.Simulation import Simulation
from omniKinematics import omniKinematics
import omniVar


class Teleop:
    def __init__(self):
        # create node
        if not rospy.get_node_uri():
            rospy.init_node('teleop_node', anonymous=True, log_level=rospy.WARN)
        else:
            rospy.logdebug(rospy.get_caller_id() + ' -> ROS already initialized')

        # members
        self.sim = Simulation()

        # To Get Gripper States
        self.m = []     # "m" denotes master device (i.e. Geomagic Touch)
        self.s = []     # "s" denotes slave device (i.e. camera manipulator in simulation)
        rospy.Subscriber('/omni/joint_states', JointState, self._omni_joint_states_callback, queue_size=1)

        t = 0.0
        while not rospy.is_shutdown():
            if not self.m:
                pass
            else:
                s_new = self.mapping(self.m, self.s)
                self.sim.update(joints=s_new, vars=[60, 30])
                self.sim.update_kin(joints=s_new, vars=[60, 30])
                self.s = s_new
                rospy.sleep(0.001)
                t += 0.001

    """
    Get Joint Positions
    """
    def _omni_joint_states_callback(self, msg):
        self.m = list(msg.position)

    """
    Master-Slave Mapping
    """
    @classmethod
    def mapping(cls, m, s):
        """
        m : Current 6 joint angles of master camera_manipulator (i.e. Geomagic Touch)
        s : Current 7 joint angles of slave camera_manipulator (i.e. Panda)
        return: joint angles of
        """
        # Get the fk from master
        Tme = omniKinematics.fk(joints=m)[0][-1]

        # Motion scale & offset pos
        pos = Tme[:3, -1]
        pos[2] += omniVar.L2
        pos *= 0.5
        pos[2] += 100
        pos[1] += 20
        Tme[:3, -1] = pos

        print (pos)

        # Solve the ik and set the joint angles of panda
        s_new = Kinematics.ik(Tb_ed=Tme, vars=[60, 30], q0=s, RRMC=True)
        return s_new


if __name__ == "__main__":
    tel = Teleop()
