import numpy as np
from camera_manipulator.teleop import omniVar


class omniKinematics:
    @classmethod
    def DH_transform(cls, dhparams):  # stacks transforms of neighbor frame, following the modified DH convention
        Ts = [np.array([[np.cos(theta), -np.sin(theta), 0, a],
                        [np.sin(theta) * np.cos(alpha), np.cos(theta) * np.cos(alpha), -np.sin(alpha),
                         -np.sin(alpha) * d],
                        [np.sin(theta) * np.sin(alpha), np.cos(theta) * np.sin(alpha), np.cos(alpha),
                         np.cos(alpha) * d],
                        [0, 0, 0, 1]]) for [alpha, a, d, theta] in dhparams]
        return Ts

    @classmethod
    def fk(cls, joints):
        """
        joints = (6,)
        Ts = (Tb1, T12, T23, ...)
        """
        Ts = omniKinematics.DH_transform(omniVar.dhparam(joints))  # Tb1, T12, T23, ...
        # Tbe = np.linalg.multi_dot(Ts)   # from base to end-effector
        Tbs = np.array(
            [np.linalg.multi_dot(Ts[:i]) if i > 1 else Ts[0] for i in range(1, len(Ts) + 1)])  # Tb1, Tb2, Tb3, ...
        # Tbs[-1]: from base to end effector
        return Tbs, Ts


if __name__ == "__main__":
    Tbe = omniKinematics.fk(joints=[0.10, 0.48, -0.19, 0.27, -0.7, 0.74])[0][-1]
    p = Tbe[:3, -1]
    from scipy.spatial.transform import Rotation
    quat = Rotation.from_matrix(Tbe[:3, :3]).as_quat()
    print (p)
    print (quat)