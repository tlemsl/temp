from scipy.spatial.transform import Rotation
import scipy.misc
import numpy as np
np.set_printoptions(precision=5, suppress=True)
import time


class Kinematics:
    @classmethod
    def DH_transform(cls, joints, vars):  # stacks transforms of neighbor frame, following the modified DH convention
        q1, q2, q3, q4, q5, q6 = np.array(joints).T
        L1, L2 = vars
        dhparams = np.array([[0, 0, q1-L1-L2, 0],
                             [0, 0, 0, q2],
                             [0, 0, 0, 0],
                             [0, 0, 0, 0],
                             [0, 0, 0, q5],
                             [0, 0, 0, 0]])
        Ts = [np.array([[np.cos(theta), -np.sin(theta), 0, a],
                        [np.sin(theta) * np.cos(alpha), np.cos(theta) * np.cos(alpha), -np.sin(alpha),
                         -np.sin(alpha) * d],
                        [np.sin(theta) * np.sin(alpha), np.cos(theta) * np.sin(alpha), np.cos(alpha), np.cos(alpha) * d],
                        [0, 0, 0, 1]]) for [alpha, a, d, theta] in dhparams]
        Ts[3][:3, :3] = np.eye(3)
        Rz = Rotation.from_euler('z', q3).as_matrix()
        if q4 == 0:
            Ts[3][:3, -1] = Rz @ np.array([0.0, 0.0, L1])
        else:
            Ts[3][:3, -1] = Rz @ np.array([0.0, L1/q4*(1-np.cos(q4)), L1/q4*np.sin(q4)])
        Rx = Rotation.from_euler('x', -q6).as_matrix()
        Rz = Rotation.from_euler('z', -q5).as_matrix()
        Ts[5][:3, :3] = Rx @ Rz
        if q6 == 0:
            Ts[5][:3, -1] = np.array([0.0, 0.0, L2])
        else:
            Ts[5][:3, -1] = np.array([0.0, L2/q6*(1-np.cos(q6)), L2/q6*np.sin(q6)])
        return Ts

    @classmethod
    def fk(cls, joints, vars):
        """
        joints = (7,)
        Ts = (Tb1, T12, T23, ...)
        """
        Ts = Kinematics.DH_transform(joints, vars)     # Tb1, T12, T23, ...
        # Tbe = np.linalg.multi_dot(Ts)   # from base to end-effector
        Tbs = np.array([np.linalg.multi_dot(Ts[:i]) if i > 1 else Ts[0] for i in range(1, len(Ts)+1)])  # Tb1, Tb2, Tb3, ...
        # Tbs[-1]: from base to end effector
        return Tbs, Ts

    @classmethod
    def jacobian(cls, Tbs):
        """
        Tbs: Tb0, Tb1, Tb2, ...
        """
        Tbe = Tbs[-1]
        J = np.zeros((6, 6))

        # trans (for q1)
        J[3:, 0] = np.array([0.0, 0.0, 0.0])
        J[:3, 0] = Tbs[0, :3, 2]    # actuation axis

        # roll (for q2)
        Zi = Tbs[1, :3, 2]  # vector of actuation axis
        Pin = (Tbe[:3, -1] - Tbs[1, :3, -1])  # pos vector from (i) to (n)
        J[3:, 1] = Zi
        J[:3, 1] = np.cross(Zi, Pin)  # Jv

        # bending (for q3, q4)
        Zi = Tbs[1, :3, 2]  # vector of actuation axis
        Pin = (Tbe[:3, -1] - Tbs[1, :3, -1])  # pos vector from (i) to (n)
        J[3:, 1] = Zi
        J[:3, 1] = np.cross(Zi, Pin)  # Jv

        # bending (for q4)
        Zi = Tbs[1, :3, 2]  # vector of actuation axis
        Pin = (Tbe[:3, -1] - Tbs[1, :3, -1])  # pos vector from (i) to (n)
        J[3:, 1] = Zi
        J[:3, 1] = np.cross(Zi, Pin)  # Jv




        return J

    @classmethod
    def ik(cls, Tb_ed, vars, q0=None, RRMC=False, k=0.1):     # inverse kinematics using Newton-Raphson Method
        """
        Tb_ed = transform from base to desired end effector
        q0 = initial configuration for iterative N-R method
        RRMC = Resolved-rate Motion Control
        k = step size (scaling) of cartesian error
        """
        if q0 is None:
            q0 = []
        assert Tb_ed.shape == (4, 4)
        st = time.time()
        if q0 == []:
            qk = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])  # initial guess
        else:
            qk = np.array(q0)
        iter = 0
        reached = False
        while not reached:
            Tbs = Kinematics.fk(joints=qk, vars=vars)[0]

            # Define Cartesian error
            Tb_ec = Tbs[-1]  # base to current ee
            Tec_ed = np.linalg.inv(Tb_ec).dot(Tb_ed)     #   transform from current ee to desired ee
            pos_err = Tb_ec[:3, :3].dot(Tec_ed[:3, -1])     # pos err in the base frame
            rot_err = Tb_ec[:3, :3].dot(Rotation.from_matrix(Tec_ed[:3, :3]).as_rotvec())  # rot err in the base frame
            err_cart = np.concatenate((pos_err, rot_err))

            # Inverse differential kinematics (Newton-Raphson method)
            J = Kinematics.jacobian(Tbs)
            Jp = np.linalg.pinv(J)
            qk_next = qk + Jp.dot(err_cart*k)
            qk = qk_next

            # Convergence condition
            print (np.linalg.norm(err_cart))
            print (qk)
            if np.linalg.norm(err_cart) < 10e-4:
                reached = True
            else:
                iter += 1
            if RRMC:
                reached = True

        print ("iter=", iter, "time=", time.time() - st)
        assert ~np.isnan(qk).any()
        return qk


if __name__ == "__main__":
    # FK
    joints = np.array([0.0, -0.702, -0.678, -0.238, -0.365, 0.703])
    # joints = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    vars = np.array([10, 10])
    Tbe = Kinematics.fk(joints=joints, vars=vars)[0][-1]

    # IK
    import time
    st = time.time()
    print("q_des=", joints)
    print("q_ik =", Kinematics.ik(Tb_ed=Tbe, vars=vars))
    print("t_comp=", time.time() - st)