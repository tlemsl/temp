import rospy
import numpy as np
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Transform, Vector3, Quaternion, Point, Pose
from scipy.spatial.transform import Rotation
from Kinematics import Kinematics


class Simulation:
    def __init__(self):
        rospy.init_node("camera_manipulator", anonymous=True)

        # config
        self.n_seg = 2
        self.n_axes = 3

        self.rod1 = Marker()
        self.rod1.header.frame_id = "map"
        self.rod1.type = Marker.SPHERE_LIST
        self.rod1.color.r, self.rod1.color.g, self.rod1.color.b, self.rod1.color.a = [0.0, 1.0, 0.0, 1.0]
        self.rod1.scale.x, self.rod1.scale.y, self.rod1.scale.z = (0.4, 0.4, 0.1)

        self.rod2 = Marker()
        self.rod2.header.frame_id = "map"
        self.rod2.type = Marker.SPHERE_LIST
        self.rod2.color.r, self.rod2.color.g, self.rod2.color.b, self.rod2.color.a = [0.0, 1.0, 0.0, 1.0]
        self.rod2.scale.x, self.rod2.scale.y, self.rod2.scale.z = (0.2, 0.2, 0.1)

        for i in range(21):
            self.rod1.points.append([])
            self.rod2.points.append([])

        # define publisher
        self.rod_pub = []
        self.disk_pub = []
        self.axes_pub = []
        self.shaft_pub = rospy.Publisher("shaft", MarkerArray, queue_size=10)
        for i in range(self.n_seg):
            self.rod_pub.append(rospy.Publisher("rod"+str(i), Marker, queue_size=10))
            self.disk_pub.append(rospy.Publisher("disk"+str(i), MarkerArray, queue_size=10))
        for i in range(self.n_axes):
            self.axes_pub.append(rospy.Publisher("axes"+str(i), MarkerArray, queue_size=10))

    def set_shaft(cls, pos, quat, length, color=None, scale=None):
        if color is None:
            color = [0.0, 1.0, 0.0, 1.0]    # green
        if scale is None:
            scale = [0.2, 0.2, length]
        shaft = MarkerArray()
        marker = Marker()
        marker.header.frame_id = "map"
        marker.header.stamp = rospy.Time.now()
        marker.id = 0
        marker.type = Marker.CYLINDER
        T1 = cls.pq_to_transform(pos, quat)
        T2 = cls.pq_to_transform([0.0, 0.0, -length/2], [0.0, 0.0, 0.0, 1.0])
        marker.pose = cls.transform_to_pose(T1 @ T2)
        marker.color.r = color[0]
        marker.color.g = color[1]
        marker.color.b = color[2]
        marker.color.a = color[3]
        marker.scale.x = scale[0]
        marker.scale.y = scale[1]
        marker.scale.z = length
        shaft.markers.append(marker)
        return shaft

    def set_rod1(self, pos, quat, theta, length, resolution, marker_type=Marker.ARROW, color=None, scale=None):
        self.rod1.pose.position.x, self.rod1.pose.position.y, self.rod1.pose.position.z = pos
        self.rod1.pose.orientation.x, self.rod1.pose.orientation.y, self.rod1.pose.orientation.z, self.rod1.pose.orientation.w = quat
        q = theta
        L = length
        path = np.arange(start=0.0, stop=L, step=1/resolution)
        for i, s in enumerate(path):

            if q == 0:
                pos = np.array([0.0, 0.0, s])
            else:
                pos = np.array([0.0, L/q*(1-np.cos(q/L*s)), L/q*np.sin(q/L*s)])
            p = Point(**dict(zip(['x', 'y', 'z'], pos)))
            self.rod1.points[i] = p

    def set_rod2(self, pos, quat, theta, length, resolution, marker_type=Marker.ARROW, color=None, scale=None):
        self.rod2.pose.position.x, self.rod2.pose.position.y, self.rod2.pose.position.z = pos
        self.rod2.pose.orientation.x, self.rod2.pose.orientation.y, self.rod2.pose.orientation.z, self.rod2.pose.orientation.w = quat
        q = theta
        L = length
        path = np.arange(start=0.0, stop=L, step=1/resolution)
        for i, s in enumerate(path):
            if q == 0:
                pos = np.array([0.0, 0.0, s])
            else:
                pos = np.array([0.0, L/q*(1-np.cos(q/L*s)), L/q*np.sin(q/L*s)])
            p = Point(**dict(zip(['x', 'y', 'z'], pos)))
            self.rod2.points[i] = p

    def numpy_to_pose(self, arr):
        shape, rest = arr.shape[:-2], arr.shape[-2:]
        assert rest == (4, 4)
        import pdb; pdb.set_trace()
        if len(shape) == 0:
            trans = np.array(arr)[:3, -1].copy()
            quat = Rotation.from_matrix(arr[:3, :3]).as_quat()

            return Pose(
                position=Point(**dict(zip(['x', 'y', 'z'], trans))),
                orientation=Quaternion(**dict(zip(['x', 'y', 'z', 'w'], quat)))
            )
        else:
            res = np.empty(shape, dtype=np.object_)
            for idx in np.ndindex(shape):
                res[idx] = Pose(
                    position=Point(
                        **dict(
                            zip(['x', 'y', 'z'],
                                np.array(arr[idx]).copy()))),
                    orientation=Quaternion(
                        **dict(
                            zip(['x', 'y', 'z', 'w'],
                                Rotation.from_matrix(arr[idx]).as_quat())))
                )
            return res

    def set_axes(cls, pos, quat, length, scale=None):
        if scale is None:
            scale = [0.1, 0.1, 0.1]
        axes = MarkerArray()
        colors = [[1.0, 0.0, 0.0, 1.0], [0.0, 1.0, 0.0, 1.0], [0.0, 0.0, 1.0, 1.0]]
        Rs = [Rotation.from_euler('y', np.pi/2).as_matrix(),
              Rotation.from_euler('x', -np.pi/2).as_matrix(), np.eye(3)]
        ps = [[length/2, 0.0, 0.0], [0.0, length/2, 0.0], [0.0, 0.0, length/2]]
        for i, (color, R, p) in enumerate(zip(colors, Rs, ps)):
            marker = Marker()
            marker.header.frame_id = "map"
            marker.header.stamp = rospy.Time.now()
            marker.id = i
            marker.type = Marker.CYLINDER
            T1 = cls.pq_to_transform(pos, quat)
            T2 = np.eye(4)
            T2[:3, :3] = R
            T2[:3, -1] = p
            marker.pose = cls.transform_to_pose(T1 @ T2)
            marker.color.r = color[0]
            marker.color.g = color[1]
            marker.color.b = color[2]
            marker.color.a = color[3]
            marker.scale.x = scale[0]
            marker.scale.y = scale[1]
            marker.scale.z = length
            axes.markers.append(marker)
        return axes

    def update(self, joints, vars):
        q1, q2, q3, q4, q5, q6, q7 = joints
        L1, L2, L3 = vars
        Tbs, Ts = Kinematics.fk(joints=joints, vars=vars)

        # calculatae poses
        pos_rod1, quat_rod1 = self.transform_to_pq(Tbs[2])
        pos_rod2, quat_rod2 = self.transform_to_pq(Tbs[5])
        pos_ee, quat_ee = self.transform_to_pq(Tbs[-1])
        pos_shaft, quat_shaft = self.transform_to_pq(Tbs[1])

        # draw shaft
        shaft = self.set_shaft(pos=pos_shaft, quat=quat_shaft, length=L1, color=(1.0, 0.7, 0.0, 1.0), scale=(0.4, 0.4, 0.0))
        self.shaft_pub.publish(shaft)

        # draw two segments
        rod1 = self.set_rod1(pos=pos_rod1, quat=quat_rod1, theta=q4, length=L2, resolution=10, marker_type=Marker.SPHERE_LIST, color=None, scale=(0.4, 0.4, 0.1))
        rod2 = self.set_rod2(pos=pos_rod2, quat=quat_rod2, theta=q7, length=L3, resolution=10, marker_type=Marker.SPHERE_LIST, color=None, scale=(0.2, 0.2, 0.1))
        # disk1 = self.set_rod(pos=pos_rod1, quat=quat_rod1, theta=q4, length=L2, resolution=2, marker_type=Marker.SPHERE, color=(1.0, 0.0, 0.0, 1.0), scale=(0.4, 0.4, 0.05))
        # disk2 = self.set_rod(pos=pos_rod2, quat=quat_rod2, theta=q7, length=L3, resolution=2, marker_type=Marker.SPHERE, color=(1.0, 0.0, 0.0, 1.0), scale=(0.3, 0.3, 0.05))
        self.rod_pub[0].publish(self.rod1)
        self.rod_pub[1].publish(self.rod2)
        # self.disk_pub[0].publish(disk1)
        # self.disk_pub[1].publish(disk2)

        # draw axes
        axes1 = self.set_axes(pos=pos_shaft, quat=quat_shaft, length=0.8, scale=(0.1, 0.1, 0.0))
        axes2 = self.set_axes(pos=pos_rod2, quat=quat_rod2, length=0.8, scale=(0.1, 0.1, 0.0))
        axes3 = self.set_axes(pos=pos_ee, quat=quat_ee, length=0.8, scale=(0.1, 0.1, 0.0))
        self.axes_pub[1].publish(axes2)
        self.axes_pub[0].publish(axes1)
        self.axes_pub[2].publish(axes3)

    @classmethod
    def pq_to_pose(cls, pos, quat):
        pose = Pose()
        pose.position.x = pos[0]
        pose.position.y = pos[1]
        pose.position.z = pos[2]
        pose.orientation.x = quat[0]
        pose.orientation.y = quat[1]
        pose.orientation.z = quat[2]
        pose.orientation.w = quat[3]
        return pose

    @classmethod
    def pq_to_transform(cls, pos, quat):
        T = np.eye(4)
        T[:3, :3] = Rotation.from_quat(quat).as_matrix()
        T[:3, -1] = pos
        return T

    @classmethod
    def transform_to_pose(cls, T):
        pos = T[:3, -1]
        quat = Rotation.from_matrix(T[:3, :3]).as_quat()
        pose = Pose()
        pose.position.x = pos[0]
        pose.position.y = pos[1]
        pose.position.z = pos[2]
        pose.orientation.x = quat[0]
        pose.orientation.y = quat[1]
        pose.orientation.z = quat[2]
        pose.orientation.w = quat[3]
        return pose

    @classmethod
    def transform_to_pq(cls, T):
        pos = T[:3, -1]
        quat = Rotation.from_matrix(T[:3, :3]).as_quat()
        return pos, quat


if __name__ == "__main__":
    sim = Simulation()
    t = 0.0
    while True:
        joints = [1.5*np.sin(2*np.pi*t/3)]*7
        joints[0] = 0.0
        joints[1] = 0.0
        joints[2] = 0.0
        joints[4] = 0.0
        joints[5] = 0.0
        sim.update(joints=joints, vars=[3, 2.1, 2.1])
        rospy.sleep(0.001)
        t += 0.001