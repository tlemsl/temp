import rospy
import numpy as np
import tf
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Transform, Vector3, Quaternion, Point, Pose
from scipy.spatial.transform import Rotation
from Kinematics import Kinematics


class Simulation:
    def __init__(self):
        rospy.init_node("camera_manipulator", anonymous=True)

        # config
        self.n_seg = 2
        self.n_disk = 10    # number of disk per each segment

        # dimension
        self.L_shaft = 50
        self.r_shaft = 8
        self.L_disk = [3, 3]
        self.r_disk = [6, 5]

        # transform broadcaster
        self.br = tf.TransformBroadcaster()

    def update_segment(self, bend, length, idx_seg):
        L = length
        self.br.sendTransform(translation=[0.0, 0.0, 0.0], rotation=Rotation.from_euler('z', bend[0]).as_quat(),
                              time=rospy.Time.now(), child="S" + str(idx_seg) + "L0", parent="S" + str(idx_seg) + "Lbase")
        path = np.arange(start=0.0, stop=L, step=L/10)
        for i, s in enumerate(path[1:], start=1):
            if bend[1] == 0:
                pos_link = np.array([0.0, 0.0, s])
            else:
                pos_link = np.array([0.0, L/bend[1]*(1-np.cos(bend[1]/L*s)), L/bend[1]*np.sin(bend[1]/L*s)])
            if i == len(path)-1:    # for the last link
                R1 = Rotation.from_euler('x', -s*bend[1]/L).as_matrix()
                R2 = Rotation.from_euler('z', -bend[0]).as_matrix()
                quat_link = Rotation.from_matrix(R1@R2).as_quat()
            else:
                quat_link = Rotation.from_euler('x', -s*bend[1]/L).as_quat()
            self.br.sendTransform(translation=pos_link, rotation=quat_link, time=rospy.Time.now(),
                                  child="S"+str(idx_seg)+"L"+str(i),
                                  parent="S"+str(idx_seg)+"L0")

    def update(self, joints, vars):
        q1, q2, q3, q4, q5, q6, q7 = joints
        L1, L2 = vars

        # update outer shaft
        self.br.sendTransform(translation=[0.0, 0.0, q1-self.L_shaft/2], rotation=[0.0, 0.0, 0.0, 1.0],
                              time=rospy.Time.now(), child="link_shaft", parent="base_link")

        # update base of the 1st segment
        self.br.sendTransform(translation=[0.0, 0.0, self.L_shaft/2], rotation=Rotation.from_euler('z', q2).as_quat(),
                              time=rospy.Time.now(), child="S0Lbase", parent="link_shaft")

        # update base of the 2nd segment
        self.br.sendTransform(translation=[0.0, 0.0, self.L_disk[1]/2], rotation=Rotation.from_euler('z', q5).as_quat(),
                              time=rospy.Time.now(), child="S1Lbase", parent="S0L9")

        # update segments
        self.update_segment(bend=[q3, q4], length=L1, idx_seg=0)     # 1st segment
        self.update_segment(bend=[q6, q7], length=L2, idx_seg=1)     # 2nd segment

    @classmethod
    def numpy_to_pose(cls, pos, quat, arr):
        shape, rest = arr.shape[:-2], arr.shape[-2:]
        assert rest == (4, 4)
        return Pose(position=Point(**dict(zip(['x', 'y', 'z'], pos))),
                    orientation=Quaternion(**dict(zip(['x', 'y', 'z', 'w'], quat))))

    @classmethod
    def transform_to_pq(cls, T):
        pos = T[:3, -1]
        quat = Rotation.from_matrix(T[:3, :3]).as_quat()
        return pos, quat

    def createURDF(self):
        with open('continuum.urdf', 'w') as file:
            file.write("<?xml version=\"1.0\"?>\n")
            file.write("<robot name=\"continuum_robot\">\n")
            file.write("<link name=\"base_link\"/>\n")
            file.write("<material name=\"color\">\n")
            file.write("<color rgba=\"0 1 1 1\"/>\n")
            file.write("</material>\n")

            file.write("<link name=\"link_shaft\">\n")
            file.write("<visual>\n")
            file.write("<geometry>\n")
            file.write("<cylinder length=\"" + str(self.L_shaft) + "\" radius=\"" + str(self.r_shaft) + "\"/>\n")
            file.write("<origin rpy=\"0 0 0\" xyz=\"0 0 0\"/>\n")
            file.write("</geometry>\n")
            file.write("<material name=\"color\"/>\n")
            file.write("</visual>\n")
            file.write("</link>\n\n")

            file.write("<joint name=\"joint_shaft\" type=\"floating\">\n")
            file.write("<parent link=\"base_link\"/>\n")
            file.write("<child link=\"link_shaft\"/>\n")
            file.write("</joint>\n\n")
            for s in range(self.n_seg):
                file.write("<link name=\"S" + str(s) + "Lbase\"/>\n")
                file.write("<joint name=\"S" + str(s) + "Jbase\" type=\"floating\">\n")
                file.write("<parent link=\"base_link\"/>\n")
                file.write("<child link=\"S" + str(s) + "Lbase\"/>\n")
                file.write("</joint>\n\n")
                for d in range(self.n_disk):
                    file.write("<link name=\"S" + str(s) + "L" + str(d) + "\">\n")
                    file.write("<visual>\n")
                    file.write("<geometry>\n")
                    file.write("<cylinder length=\"" + str(self.L_disk[s]) + "\" radius=\"" + str(self.r_disk[s]) + "\"/>\n")
                    file.write("<origin rpy=\"0 0 0\" xyz=\"0 0 0\"/>\n")
                    file.write("</geometry>\n")
                    file.write("<material name=\"color\"/>\n")
                    file.write("</visual>\n")
                    file.write("</link>\n\n")

                    file.write("<joint name=\"S" + str(s) + "J" + str(d) + "\" type=\"floating\">\n")
                    file.write("<parent link=\"base_link\"/>\n")
                    file.write("<child link=\"S" + str(s) + "L" + str(d) + "\"/>\n")
                    file.write("</joint>\n\n")
            file.write("</robot>\n\n")


if __name__ == "__main__":
    sim = Simulation()
    t = 0.0
    sim.createURDF()

    import roslaunch
    uuid = roslaunch.rlutil.get_or_generate_uuid(None, False)
    roslaunch.configure_logging(uuid)
    launch = roslaunch.parent.ROSLaunchParent(uuid, ["sim.launch"])
    launch.start()
    # try:
    #     launch.spin()
    # finally:
    #     launch.shutdown()
    while True:
        joints = [1.5*np.sin(2*np.pi*t/3)]*7
        joints[0] = 0.0     # trans
        joints[1] = 0.0     # outer rollanfvna
        joints[2] = np.pi/6     # bending (1st seg)
        # joints[3] = 0.0     # bending (1st seg)
        joints[4] = 0.0     # inner roll
        joints[5] = 0.0     # bending (2nd seg)
        joints[6] = 0.0     # bending (2nd seg)
        sim.update(joints=joints, vars=[60, 40])
        rospy.sleep(0.001)
        t += 0.001