
"use strict";

let epos_motor_info = require('./epos_motor_info.js');

module.exports = {
  epos_motor_info: epos_motor_info,
};
