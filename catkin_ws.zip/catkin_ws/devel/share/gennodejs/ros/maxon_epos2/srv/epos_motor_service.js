// Auto-generated. Do not edit!

// (in-package maxon_epos2.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class epos_motor_serviceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.position_setpoint = null;
    }
    else {
      if (initObj.hasOwnProperty('position_setpoint')) {
        this.position_setpoint = initObj.position_setpoint
      }
      else {
        this.position_setpoint = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type epos_motor_serviceRequest
    // Serialize message field [position_setpoint]
    bufferOffset = _serializer.float32(obj.position_setpoint, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type epos_motor_serviceRequest
    let len;
    let data = new epos_motor_serviceRequest(null);
    // Deserialize message field [position_setpoint]
    data.position_setpoint = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'maxon_epos2/epos_motor_serviceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9e94ec84848c71f46b874cbfbcd69fdf';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 position_setpoint
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new epos_motor_serviceRequest(null);
    if (msg.position_setpoint !== undefined) {
      resolved.position_setpoint = msg.position_setpoint;
    }
    else {
      resolved.position_setpoint = 0.0
    }

    return resolved;
    }
};

class epos_motor_serviceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.position = null;
      this.velocity = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('position')) {
        this.position = initObj.position
      }
      else {
        this.position = 0.0;
      }
      if (initObj.hasOwnProperty('velocity')) {
        this.velocity = initObj.velocity
      }
      else {
        this.velocity = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type epos_motor_serviceResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [position]
    bufferOffset = _serializer.float32(obj.position, buffer, bufferOffset);
    // Serialize message field [velocity]
    bufferOffset = _serializer.float32(obj.velocity, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type epos_motor_serviceResponse
    let len;
    let data = new epos_motor_serviceResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [position]
    data.position = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [velocity]
    data.velocity = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'maxon_epos2/epos_motor_serviceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c255e7e841eac8ea6b6a532815001e2c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    float32 position
    float32 velocity
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new epos_motor_serviceResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.position !== undefined) {
      resolved.position = msg.position;
    }
    else {
      resolved.position = 0.0
    }

    if (msg.velocity !== undefined) {
      resolved.velocity = msg.velocity;
    }
    else {
      resolved.velocity = 0.0
    }

    return resolved;
    }
};

module.exports = {
  Request: epos_motor_serviceRequest,
  Response: epos_motor_serviceResponse,
  md5sum() { return 'f697830cb399e19fb73b1e52df97e585'; },
  datatype() { return 'maxon_epos2/epos_motor_service'; }
};
