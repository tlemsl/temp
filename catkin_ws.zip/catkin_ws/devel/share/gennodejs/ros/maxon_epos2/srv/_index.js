
"use strict";

let epos_motor_service = require('./epos_motor_service.js')

module.exports = {
  epos_motor_service: epos_motor_service,
};
