# oCamS-1CGN-U-Driver
This is oCamS-1CGN-U Stereo camera ROS Driver for Opencv 4.4.0

[Previous Driver](https://github.com/withrobot/oCamS/tree/master/Software/oCamS_ROS_Package) is use very low version of Opencv (May be lower Opencv 3). In this case, an error may occur when building a package(catkin_make). So, this driver solved these problems.

## Test Env
 - Ubuntu 20.04
 - Opencv 4.4.0
 - ROS Noetic
